Every images are scrapped from google. Train and test set are divided into 80% and 20%. 

Prepared by Nirajan Thakuri.